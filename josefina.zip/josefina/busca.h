#ifndef BUSCA_H_INCLUDED
#define BUSCA_H_INCLUDED
#include "grafo.h"

void buscaLargura(Grafo *grafo, int v, int visitou[], int refe[], int quant);

#endif // BUSCA_H_INCLUDED
