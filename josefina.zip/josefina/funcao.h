#ifndef FUNCAO_H_INCLUDED
#define FUNCAO_H_INCLUDED

int soma(int valor, int vet[], int quant);
int subtracao(int valor, int vet[], int quant);
int multiplicacao2(int valor, int vet[], int quant);
int multiplicacao3(int valor, int vet[], int quant);
int divisao2(int valor, int vet[], int quant);

#endif // FUNCAO_H_INCLUDED
